package gui;

public class Constantes {

	public final static int CANCELAR = 0;
	public final static int INSERTAR = 1;
	public final static int MODIFICAR = 2;
	public final static int BORRAR = 3;
	
}
