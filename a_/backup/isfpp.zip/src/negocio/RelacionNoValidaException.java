package negocio;

@SuppressWarnings("serial")
public class RelacionNoValidaException extends RuntimeException {

	/**
	 * 
	 */
	public RelacionNoValidaException() {
		super();

	}

	public RelacionNoValidaException(String message) {
		super(message);
	}

}
