package datos;

public class RelacionRepetidaException extends RuntimeException {

	/**
	 * 
	 */
	public RelacionRepetidaException() {
		super();
	}

	/**
	 * @param message
	 */
	public RelacionRepetidaException(String message) {
		super(message);
	}

}
