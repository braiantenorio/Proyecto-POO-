package negocio;

public class UsuarioNoValidoException extends RuntimeException {

	/**
	 * 
	 */
	public UsuarioNoValidoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public UsuarioNoValidoException(String message) {
		super(message);
	}

}