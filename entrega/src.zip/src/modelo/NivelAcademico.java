package modelo;

/**
 * Una enumeracion de niveles academicos
 */
public enum NivelAcademico {
	PRIMARIO, SECUNDARIO, TERCIARIO, UNIVERSITARIO, NULO
}
