package modelo;

/**
 * Una enumeracion de generos
 */
public enum Genero {
	X, F, M
}